<?php

namespace App;

use Illuminate\Notifications\Notifiable;
use Illuminate\Contracts\Auth\MustVerifyEmail;
use Illuminate\Foundation\Auth\User as Authenticatable;

class User extends Authenticatable
{
    use Notifiable;

    /**
     * The attributes that are mass assignable.
     *
     * @var array
     */
    protected $fillable = [
        'username', 'email', 'password', 'alamat', 'avatar'
    ];

    /**
     * The attributes that should be hidden for arrays.
     *
     * @var array
     */
    protected $hidden = [
        'password', 'remember_token',
    ];

    /**
     * The attributes that should be cast to native types.
     *
     * @var array
     */
    protected $casts = [
        'email_verified_at' => 'datetime',
    ];

    public function komen () {
        return $this->hasMany('App\komen', 'id_user');
    }

    public function order () {
        return $this->hasMany('App\order', 'id_user');
    }

    public function resep() {
        return $this->hasMany('App\resep', 'id_user', 'id');
    }

    public function report() {
        return $this->hasMany('App\Report', 'id_user', 'id');
    }
}
