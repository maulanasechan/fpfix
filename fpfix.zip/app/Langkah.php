<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Langkah extends Model
{
    protected $table ="langkah";
}
