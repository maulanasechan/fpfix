<!DOCTYPE html>
<html lang="en">
<head>
  <title>List of Product</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link href="<?php echo e(asset('css/style.css')); ?>" rel="stylesheet">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.0/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.0/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.0/js/bootstrap.min.js"></script>
</head>
<body>
<img src="/img/mppl11.png" class="login-img9">  
<img src="/img/mppl12.png" class="login-img10">
<img src="/img/mppl12.png" class="login-img11"> 
<img src="/img/mppl13.png" class="login-img12"> 
<img src="/img/mppl15.png" class="login-img15">   
<p class="judul" style="top: 17%; word-spacing: 30px;">List of Product</p>
<center><div class="container" style="top: 50%">
  <table class="table" style="width: 85%;">
    <thead>
      <tr>
        <th>ID Barang</th>
        <th>ID Penjual</th>
        <th>Nama Barang</th>
        <th>Deskripsi</th>
        <th>Harga</th>
        <th>Tipe</th>
        <th>Gambar Produk</th>
        <th>Created At</th>
        <th>Menu</th>
      </tr>
    </thead>
    <tbody>
      <?php if(count($marketplace)): ?>
        <?php $__currentLoopData = $marketplace; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $u): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
          <tr class="success">
            <td><?php echo e($u->id_barang); ?></td>
            <td><?php echo e($u->id_penjual); ?></td>
            <td><?php echo e($u->nama_barang); ?></td>
            <td><?php echo e($u->deskripsi); ?></td>
            <td><?php echo e($u->harga); ?></td>
            <?php if($u->tipe == 1): ?>
              <td>Appetizer</td>
            <?php elseif($u->tipe == 2): ?>
              <td>Main Course</td>
            <?php elseif($u->tipe == 3): ?>
              <td>Dessert</td>
            <?php endif; ?>
            <td><img src="/storage/<?php echo e($u->filename); ?>" style="width: auto; max-height: 50px; margin: 0 auto; display: block;"></td>
            <td><?php echo e($u->created_at); ?></td>
            <form method="GET" action="<?php echo e(route('penjual.update')); ?>">
              <?php echo csrf_field(); ?>
                  <input type="hidden" name="table" value="1">
                  <input type="hidden" name="id" value="<?php echo e($u->id_barang); ?>">
                <td><button class='btn btn-sm btn-danger delete-btn' type='submit' style="background-color: #354857; border : none;">Update </button></td>  
            </form> 
            <form method="POST" action="<?php echo e(route('penjual.deleteItem')); ?>">
              <?php echo csrf_field(); ?>
                  <input type="hidden" name="table" value="1">
                  <input type="hidden" name="id" value="<?php echo e($u->id_barang); ?>">
                <td><button class='btn btn-sm btn-danger delete-btn' type='submit' style="border : none;">Delete </button></td>  
            </form>
          </tr>      
          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        <?php else: ?>
          <p>Belum Ada Data</p>
        <?php endif; ?>
    </tbody>
  </table>
  <?php echo e($marketplace->links()); ?>

</div>
</center>

<a href="<?php echo e(route('penjual.dashboard')); ?>" class="logout" style="top: 81%;">Back</a>
<a href="<?php echo e(route('marketplace.create')); ?>" class="logout" style="top: 74%;">Add</a>
<form id="logout-form" action="<?php echo e(route('penjual.logout')); ?>" method="POST">
    <?php echo csrf_field(); ?>
    <button type="submit" class="logout"><?php echo e(__('Logout')); ?></button>
</form>
</body>
</html><?php /**PATH E:\html\fpfix\resources\views/penjual/product/index.blade.php ENDPATH**/ ?>