<!doctype html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">
    <head>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">

        <title>Register User</title>

        <!-- Fonts -->
        <link href="https://fonts.googleapis.com/css?family=Nunito:200,600" rel="stylesheet">
        <link href="<?php echo e(asset('css/style.css')); ?>" rel="stylesheet">
        <!-- Styles -->
        <style>
            
        </style>
    </head>
    <body>
        <a href="/" class="register-link">Login</a>
        <img src="/img/mppl9.png" class="login-img1">
        <img src="/img/mppl3.png" class="login-img2" style="height: 25%; top: 22%;">
        <img src="/img/mppl4.png" class="login-img6">
        <img src="/img/mppl8.png" class="login-img8">
        <img src="/img/mppl10.png" class="login-img7">
        <form method="POST" action="<?php echo e(route('register')); ?>" enctype="multipart/form-data">
            <?php echo csrf_field(); ?>

            <center>
                    <input id="username" type="text" class="form-control<?php echo e($errors->has('username') ? ' is-invalid' : ''); ?>" name="username" value="<?php echo e(old('username')); ?>" required autofocus placeholder="Username" style="top: 50%; height: 7%">

                    <?php if($errors->has('username')): ?>
                        <div class="alert">
                        <span class="closebtn" onclick="this.parentElement.style.display='none';">&times;</span>
                        <span class="invalid-feedback" role="alert">
                            <strong><?php echo e($errors->first('username')); ?></strong>
                        </span>
                    </div>
                    <?php endif; ?>
            </center>

            <center>
                    <input id="email" type="text" class="form-control<?php echo e($errors->has('email') ? ' is-invalid' : ''); ?>" name="email" value="<?php echo e(old('email')); ?>" required placeholder="Email" style="top: 58%; height: 7%">

                    <?php if($errors->has('email')): ?>
                        <div class="alert">
                        <span class="closebtn" onclick="this.parentElement.style.display='none';">&times;</span>
                        <span class="invalid-feedback" role="alert">
                            <strong><?php echo e($errors->first('email')); ?></strong>
                        </span>
                    </div>
                    <?php endif; ?>
            </center>

            <center>
                    <input id="alamat" type="text" name="alamat" required placeholder="Alamat" value="<?php echo e(old('alamat')); ?>" class="form-control<?php echo e($errors->has('alamat') ? ' is-invalid' : ''); ?>" style="top: 66%; height: 7%">

                    <?php if($errors->has('alamat')): ?>
                        <div class="alert">
                        <span class="closebtn" onclick="this.parentElement.style.display='none';">&times;</span>
                        <span class="invalid-feedback" role="alert">
                            <strong><?php echo e($errors->first('alamat')); ?></strong>
                        </span>
                    </div>
                    <?php endif; ?>
            </center>

            <center>
                    <input id="password" type="password" class="form-control<?php echo e($errors->has('password') ? ' is-invalid' : ''); ?>" name="password" required placeholder="Password" style="top: 74%; height: 7%">

                    <?php if($errors->has('password')): ?>
                    <div class="alert">
                        <span class="closebtn" onclick="this.parentElement.style.display='none';">&times;</span>
                        <span class="invalid-feedback" role="alert">
                            <strong><?php echo e($errors->first('password')); ?></strong>
                        </span>
                    </div>
                    <?php endif; ?>
            </center>

            <center>
                    <input id="password-confirm" type="password" class="form-control" name="password_confirmation" required placeholder="Re-type Password" style="top: 82%; height: 7%">
            </center>

            <center>
                    <input id="avatar" type="hidden" name="avatar" value="/img/user.jpg">
            </center>

            <center>
                    <button type="submit" class="round-button-login-new" style="top: 92.2%; width: 5%; height: 10%">
                        <?php echo e(__('Register')); ?>

                    </button>
            </center>       
        </form>
    </body>
</html>
<?php /**PATH E:\html\fpfix\resources\views/auth/register.blade.php ENDPATH**/ ?>