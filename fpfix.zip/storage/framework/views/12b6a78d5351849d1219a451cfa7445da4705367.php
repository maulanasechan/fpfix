<!doctype html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">
    <head>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">

        <title>List of Transaction</title>

        <!-- Fonts -->
        <link href="https://fonts.googleapis.com/css?family=Nunito:200,600" rel="stylesheet">
        <link href="<?php echo e(asset('css/style.css')); ?>" rel="stylesheet">
        <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.0/css/bootstrap.min.css">
        <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.0/jquery.min.js"></script>
        <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.0/js/bootstrap.min.js"></script>
        <style>
            
        </style>
    </head>
    <body style="background-color: white">
        <p class="judul" style="top: 15%;">List of Transaction</p>
        <img src="/img/mppl11.png" class="login-img9">  
        <img src="/img/mppl12.png" class="login-img10">
        <img src="/img/mppl12.png" class="login-img11" style="top: 55%;"> 
        <img src="/img/mppl13.png" class="login-img12"> 
        <img src="/img/mppl15.png" class="login-img15"> 
        
        <div class="container" style="top: 47%; width: 60%">
          <table class="table">
            <thead>
              <tr>
                <th>Nama Barang</th>
                <th>Harga</th>
                <th>Amount</th>
                <th>Total Harga</th>
                <th>Status</th>
                <th>Resi</th>
                <th>Bukti</th>
                <th>Tanggal Order</th>
                <th>Menu</th>
              </tr>
            </thead>
            <tbody>
            <?php $__currentLoopData = $order; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
              <tr class="success">
                <td><?php echo e($item->barang_dijual->nama_barang); ?></td>
                <td><?php echo e($item->barang_dijual->harga); ?></td>
                <td><?php echo e($item->amount); ?></td>
                <td><?php echo e($item->amount*$item->barang_dijual->harga); ?></td>
                <?php if(!isset($item->bukti)): ?>
                    <td>Silahkan upload bukti transfer didetail order</td>
                <?php elseif(!isset($item->resi)): ?>
                    <td>Barang sedang diproses</td>
                <?php elseif($item->status == 0): ?>
                    <td>Barang sedang dikirim</td>
                <?php elseif($item->status == 1): ?>
                    <td>Barang telah diterima</td>
                <?php endif; ?>
                <?php if(isset($item->resi)): ?>
                <td><img src="/storage/<?php echo e($item->resi); ?>" style="height: 10%; width: auto"></td>
                <?php else: ?>
                <td></td>
                <?php endif; ?>
                <td><img src="<?php echo e($item->bukti); ?>" style="height: 8%"></td>
                <td><?php echo e($item->created_at->format('d M Y')); ?></td>
                <td>
                    <form method="POST" action="<?php echo e(route('profil.barangDiterima')); ?>">
                        <?php echo csrf_field(); ?>
                        <input type="hidden" name="id" value="<?php echo e($item->id); ?>">
                        <?php if($item->status != 1): ?>
                          <button class='btn btn-sm btn-success delete-btn' type='submit'>Barang Diterima </button>    
                        <?php else: ?>
                          <button disabled class='btn btn-sm btn-success delete-btn' type='submit'>Barang Diterima </button>    
                        <?php endif; ?>
                      </form>
                    
                    <a class="btn btn-sm btn-primary delete-btn" href="/profil/detail/<?php echo e($item->id); ?>">Detail Order</a>
                </td>
              </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>         
            </tbody>
          </table>
        </div>
        <?php
            $avatar = Auth::user()->avatar;
        ?>
        <img class="crop" style="width: 98px; height: 98px; object-fit: cover" src=<?php echo $avatar ?>>
        <a href="/profil" class="home-link" style="left: 6%; top: 49%; font-size: 150%">Profile</a>
        <a href="/home" class="logout" style="top: 80%;">Back</a>
        <form id="logout-form" action="<?php echo e(route('user.logout')); ?>" method="POST">
            <?php echo csrf_field(); ?>
            <button type="submit" class="logout"><?php echo e(__('Logout')); ?></button>
        </form>
    </body>
</html>

<?php /**PATH E:\html\fpfix\resources\views/profil/list.blade.php ENDPATH**/ ?>